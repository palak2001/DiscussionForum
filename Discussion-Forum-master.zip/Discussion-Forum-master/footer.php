<div class="cleared"></div><div class="art-Footer">
                    <div class="art-Footer-inner">
                       <!-- <a href="#" class="art-rss-tag-icon" title="RSS"></a>-->
                        <div class="art-Footer-text">
                        <p><b><font color ="White">Contact Us</font></b></p>
    <table>
    
	
    <tr><td><b><font color ="White">Name</font></b></td><td>:</td><td><b><font color ="White">Team Quest</font></b></td></tr>
    <tr><td rowspan="1"><b><font color ="White">Contact No</font></b></td><td>:</td><td><b><font color ="White">901-----97</font></b></td></tr>
    <tr><td rowspan="1"><b><font color ="White">E-Mail Add</font></b></td><td>:</td><td><b><font color ="White">iit2018119@iiita.ac.in</font></b></td></tr>
   
    </table><!-- | <a href="terms.php">Terms of Use</a> 
                                | <a href="prvs.php">Privacy Statement</a> | <a href="isuser.php">Online User</a><br />
                                Copyright &copy; 2012 ---. All Rights Reserved.--></p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
            </div>
        </div>
           
</body>



</html>
