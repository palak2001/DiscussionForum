<?php  require("header.php"); ?>
<?php
$greeting = "Hello!";
$month = 8;
$year = 2019;
?>
<script type="text/javascript">
	document.getElementById("acontact").className="active";
</script>


	<h1>Contact Us</h1>
    <table>
    
	
    <tr><td rowspan="4"><img src="ups/satish.jpg" style='height:100px; width:100px';></td><td>Name</td><td>:</td><td>Phptpoint</td></tr>
    <tr><td rowspan="1">Contact No</td><td>:</td><td>9015501897</td></tr>
    <tr><td rowspan="1">E-Mail Add</td><td>:</td><td>phptpoint@gmail.com</td></tr>
   <tr><td rowspan="1">Website</td><td>:</td><td><a href="http://www.phptpoint.com/">www.phptpoint.com</a></td></tr>
    </table>
    <?php
$greeting = "Hello!";
$month = 8;
$year = 2019;
?>
<?php require("footer.php"); ?>
